(function(){
  const year = document.querySelectorAll('[data-year]');
  year.forEach(el => el.textContent = new Date().getFullYear());

  const questionForm = document.querySelector('#question-form');
  if(questionForm){
    questionForm.addEventListener('submit', function(e){
      e.preventDefault();
      const name = document.querySelector('#name').value.trim();
      const topic = document.querySelector('#topic').value.trim();
      const question = document.querySelector('#question').value.trim();
      const subject = encodeURIComponent('Menstrual Muse question: ' + (topic || 'Menstrual health'));
      const body = encodeURIComponent('Name: ' + (name || 'Anonymous') + '\n\nQuestion:\n' + question + '\n\nSent through the Menstrual Muse website.');
      window.location.href = `mailto:info@musemenstrual.org?subject=${subject}&body=${body}`;
    });
  }

  document.querySelectorAll('[data-menu-toggle]').forEach(btn=>{
    btn.addEventListener('click',()=>document.querySelector('.nav-links')?.classList.toggle('open'));
  });

  /* ---------- Netlify Identity: sign-in used site-wide, gates members.html ---------- */
  function initIdentity(){
    var widget = window.netlifyIdentity;
    if(!widget) return; // script blocked or offline; nav still degrades to a plain login link

    function paintUser(user){
      var loginLinks = document.querySelectorAll('[data-auth="login"]');
      var logoutLinks = document.querySelectorAll('[data-auth="logout"]');
      var nameSlots = document.querySelectorAll('[data-auth="name"]');
      loginLinks.forEach(function(el){ el.classList.toggle('member-hidden', !!user); });
      logoutLinks.forEach(function(el){ el.classList.toggle('member-hidden', !user); });
      nameSlots.forEach(function(el){ el.textContent = user ? (user.user_metadata && user.user_metadata.full_name ? user.user_metadata.full_name.split(' ')[0] : user.email) : ''; });

      var lock = document.querySelector('[data-member-lock]');
      var area = document.querySelector('[data-member-area]');
      if(lock && area){
        lock.classList.toggle('member-hidden', !!user);
        area.style.display = user ? 'block' : 'none';
      }
    }

    widget.on('init', paintUser);
    widget.on('login', function(user){ paintUser(user); widget.close(); });
    widget.on('logout', function(){ paintUser(null); });

    document.querySelectorAll('[data-auth="login"]').forEach(function(btn){
      btn.addEventListener('click', function(e){ e.preventDefault(); widget.open('login'); });
    });
    document.querySelectorAll('[data-auth="signup"]').forEach(function(btn){
      btn.addEventListener('click', function(e){ e.preventDefault(); widget.open('signup'); });
    });
    document.querySelectorAll('[data-auth="logout"]').forEach(function(btn){
      btn.addEventListener('click', function(e){ e.preventDefault(); widget.logout(); });
    });

    paintUser(widget.currentUser());
  }
  if(document.querySelector('[data-netlify-identity-menu]')){
    if(window.netlifyIdentity){ initIdentity(); }
    else { document.addEventListener('DOMContentLoaded', function(){ setTimeout(initIdentity, 300); }); }
  }
})();
