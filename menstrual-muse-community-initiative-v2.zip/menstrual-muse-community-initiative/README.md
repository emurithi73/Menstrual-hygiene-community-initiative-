# Menstrual Muse Community Initiative website

A lightweight, semantic static website prepared for Netlify (uses two Netlify-native features — Forms and Identity — so it needs Netlify specifically, or equivalent services swapped in on another host).

## Pages
- `index.html` - Home, mission, vision, sponsorship, partnership and support calls to action.
- `learn.html` - Learning hub, menstrual health basics, FAQ and a quick email-workflow question form.
- `gallery.html` - Gallery and community-impact presentation.
- `about.html` - Story, founder note, and team.
- `events.html` - Upcoming workshops/campaigns and past highlights. **Contains placeholder dates/venues — replace with real ones before launch.**
- `donate.html` - Ways to give. **Contains placeholder payment instructions — add real M-Pesa/bank details before launch.**
- `contact.html` - Real contact form (see Netlify Forms below).
- `resources.html` - Members-only facilitator resources, gated behind Netlify Identity sign-in.

## Assets
- `assets/brand-logo.png` - extracted brand mark from the supplied Menstrual Muse gallery PDF.
- `assets/Menstrual_Muse_Handbook_V1.pdf` - supplied educator handbook.
- `assets/Menstrual_Muse_Gallery_Source.pdf` - campaign artwork source, unlocked for signed-in members.
- `assets/gallery/` - selected images rendered from the supplied gallery PDF.

## Setting up the real contact form (Netlify Forms)
No backend needed — Netlify detects the `<form data-netlify="true">` in `contact.html` at build/deploy time automatically.
1. Deploy the site to Netlify as usual (drag-and-drop the folder, or connect the repo).
2. Go to **Site settings → Forms** in the Netlify dashboard — you should see a "contact" form listed after the first deploy.
3. Under **Forms → Form notifications**, add an email notification to `info@musemenstrual.org` so submissions land in your inbox.
4. Submissions also appear directly in the Netlify dashboard under **Forms → contact**.
The form includes a honeypot field for spam protection. No code changes needed.

## Setting up member sign-in (Netlify Identity)
`resources.html` is gated using Netlify Identity, a free authentication service built into Netlify for static sites.
1. In the Netlify dashboard, go to **Site settings → Identity → Enable Identity**.
2. Under **Registration**, choose "Open" (anyone can sign up) or "Invite only" (you invite educators/volunteers manually) — invite-only is recommended for a small facilitator group.
3. That's it — the widget script is already included on every page (`netlify-identity-widget.js`), and `resources.html` shows a lock screen until someone signs in, then reveals the handbook, campaign artwork and a facilitator quick-start guide.
4. To manually invite someone: **Identity tab → Invite users**.
Until Identity is enabled on the live site, the Log In / Create Account buttons on `resources.html` will not do anything — this is expected on an un-configured Netlify site.

## Contact details configured
- Email: info@musemenstrual.org
- Gmail: musemenstrual@gmail.com
- Call: +254 736 190003
- WhatsApp only: 0743320027
- TikTok: @menstrualmuse
- Facebook: @menstrualmuseofficial
- Instagram: @menstrualmuse
- YouTube: @menstrual_muse

The Ask Questions form uses a `mailto:` workflow, so it does not require a backend server.


## Corrected contact details
- Primary email: info@musemenstrual.org
- Gmail: musemenstrual@gmail.com
- Call: +254 736 190003
- WhatsApp only: 0743320027
- TikTok: @menstrualmuse
- Facebook: @menstrualmuseofficial
- Instagram: @menstrualmuse
- YouTube: @menstrual_muse
